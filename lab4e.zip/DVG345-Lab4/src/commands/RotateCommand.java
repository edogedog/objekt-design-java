
package commands;

import java.util.Objects;

import figures.Figure;
import geometry.Point2;
import model.DrawingDocument;

public class RotateCommand implements Command {

    private final DrawingDocument document;
    private final Figure figure;
    private final double radians;
    private final Point2 pivot;

    public RotateCommand(DrawingDocument document, Figure figure, double radians) {
        this(document, figure, radians, Objects.requireNonNull(figure).getCenter());
    }

    public RotateCommand(DrawingDocument document, Figure figure, double radians, Point2 pivot) {
        this.document = Objects.requireNonNull(document);
        this.figure = Objects.requireNonNull(figure);
        this.pivot = Objects.requireNonNull(pivot);

        if (!Double.isFinite(radians)) {
            throw new IllegalArgumentException();
        }

        this.radians = radians;
    }

    @Override
    public void execute() {
        figure.rotate(radians, pivot);
        document.changed();
    }

    @Override
    public void undo() {
        figure.rotate(-radians, pivot);
        document.changed();
    }
}
