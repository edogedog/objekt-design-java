
package commands;

import java.util.List;
import java.util.Objects;
import figures.Figure;
import model.DrawingDocument;
import model.Groups;
import model.Selection;

public class GroupCommand implements Command {

    private final DrawingDocument document;
    private final Selection selection;
    private final boolean split;
    private final List<Figure> before;
    private final List<Figure> selectedBefore;
    private List<Figure> after;
    private List<Figure> selectedAfter;

    public GroupCommand(DrawingDocument document, Selection selection, boolean split) {
        this.document = Objects.requireNonNull(document);
        this.selection = Objects.requireNonNull(selection);
        this.split = split;

        before = document.figures();
        selectedBefore = selection.figures();
    }

    @Override
    public void execute() {
        if (after == null) {
            if (split) {
                Groups.ungroup(document, selection);
            } else {
                Groups.group(document, selection);
            }

            after = document.figures();
            selectedAfter = selection.figures();
        } else {
            document.replace(after);
            select(selectedAfter);
        }
    }

    @Override
    public void undo() {
        document.replace(before);
        select(selectedBefore);
    }

    private void select(List<Figure> figures) {
        selection.clear();

        for (Figure figure : figures) {
            selection.toggle(figure);
        }
    }
}
