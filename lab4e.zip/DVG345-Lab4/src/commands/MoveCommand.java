
package commands;

import java.util.Objects;

import figures.Figure;
import model.DrawingDocument;

public class MoveCommand implements Command {

    private final DrawingDocument document;
    private final Figure figure;
    private final double dx;
    private final double dy;

    public MoveCommand(DrawingDocument document, Figure figure, double dx, double dy) {
        this.document = Objects.requireNonNull(document);
        this.figure = Objects.requireNonNull(figure);

        if (!Double.isFinite(dx) || !Double.isFinite(dy)) {
            throw new IllegalArgumentException();
        }

        this.dx = dx;
        this.dy = dy;
    }

    @Override
    public void execute() {
        figure.move(dx, dy);
        document.changed();
    }

    @Override
    public void undo() {
        figure.move(-dx, -dy);
        document.changed();
    }
}
