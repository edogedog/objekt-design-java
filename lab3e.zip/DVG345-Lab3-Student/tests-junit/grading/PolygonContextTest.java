package grading;
import figures.*;
import geometry.*;
import rendering.DrawingContext;
import java.util.List;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class PolygonContextTest
  {
  private static final class PolygonRecorder implements DrawingContext
    {
    private final List<List<Point2>> polygons = new ArrayList<>();
    public void line(Point2 a, Point2 b) { fail("Rektanglar och kvadrater ska använda polygon från labb 3."); }
    public void circle(Point2 center, double radius) { fail("Fel ritoperation."); }
    public void polygon(List<Point2> vertices) { polygons.add(List.copyOf(vertices)); }
    }

  @Test @DisplayName("Polygon: rektangel och kvadrat skickar fyra hörn i kantordning")
  void shapeContours()
    {
    for (Figure figure : List.of(new Rectangle(new Point2(10,20),8,4), new Square(new Point2(10,20),8)))
      {
      var port = new PolygonRecorder();
      figure.draw(port);
      assertEquals(1, port.polygons.size());
      assertEquals(4, port.polygons.get(0).size());
      assertEquals(4, new java.util.HashSet<>(port.polygons.get(0)).size());
      // Other geometry tests verify the actual four sides before and after transformations.
      }
    }

  @Test @DisplayName("Polygon: HitTest inkluderar slutkanten men inte insidan")
  void hitContour()
    {
    Figure rectangle = new Rectangle(new Point2(20,20),80,60);
    assertTrue(HitTest.hits(rectangle,new Point2(15,50)), "Slutkanten måste kopplas till första hörnet.");
    assertFalse(HitTest.hits(rectangle,new Point2(10,50)));
    assertFalse(HitTest.hits(rectangle,new Point2(60,50)), "Polygonkonturen är ofylld.");
    rectangle.rotate(Math.PI/2,new Point2(0,0));
    assertTrue(HitTest.hits(rectangle,new Point2(-50,15)));
    }

  @Test @DisplayName("Polygon: gruppens förkontroll upptäcker hörnöverflöd före flyttning")
  void atomicTranslation()
    {
    Figure circle = new Circle(new Point2(0,0),1);
    Figure rectangle = new Rectangle(new Point2(1e308,0),1e307,10);
    var group = new CompositeFigure(List.of(circle,rectangle));
    assertThrows(IllegalArgumentException.class, () -> group.move(1e308,0));
    assertEquals(new Point2(0,0),circle.getCenter());
    assertEquals(new Point2(1.05e308,5),rectangle.getCenter());
    }

  @Test @DisplayName("Polygon: gruppens rotationsförkontroll upptäcker hörnöverflöd")
  void atomicRotation()
    {
    Figure circle = new Circle(new Point2(0,0),1);
    Figure rectangle = new Rectangle(new Point2(1e308,0),1e307,10);
    var group = new CompositeFigure(List.of(circle,rectangle));
    assertThrows(IllegalArgumentException.class,
        () -> group.rotate(Math.PI,new Point2(-1e308,0)));
    assertEquals(new Point2(0,0),circle.getCenter());
    }

  @Test @DisplayName("Polygon: AWT ritar en sluten ofylld kontur utan att ändra listan")
  void awtContour()
    {
    var image = new java.awt.image.BufferedImage(100,100,java.awt.image.BufferedImage.TYPE_INT_RGB);
    var graphics = image.createGraphics();
    var points = List.of(new Point2(20,20),new Point2(80,20),new Point2(80,80),new Point2(20,80));
    try
      {
      graphics.setColor(java.awt.Color.WHITE); graphics.fillRect(0,0,100,100);
      graphics.setColor(java.awt.Color.BLACK);
      var context = new app.AwtDrawingContext(graphics);
      context.polygon(points);
      assertEquals(java.awt.Color.BLACK.getRGB(),image.getRGB(20,50));
      assertEquals(java.awt.Color.BLACK.getRGB(),image.getRGB(50,20));
      assertEquals(java.awt.Color.WHITE.getRGB(),image.getRGB(50,50));
      assertEquals(new Point2(20,20),points.get(0));
      assertThrows(IllegalArgumentException.class, () -> context.polygon(List.of(points.get(0),points.get(1))));
      assertThrows(NullPointerException.class, () -> context.polygon(null));
      }
    finally { graphics.dispose(); }
    }
  }
