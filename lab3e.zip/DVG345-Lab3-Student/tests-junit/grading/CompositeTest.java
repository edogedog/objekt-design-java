package grading;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Timeout;
import static org.junit.jupiter.api.Assertions.*;
import figures.*;
import geometry.Point2;
import java.util.List;

@Timeout(5)
public class CompositeTest
  {
  @Test @DisplayName("Sammansättning: instansfälten är privata, även i basklasser")
  void compositeFieldsArePrivate()
    {
    Support.assertPrivateInstanceFields(CompositeFigure.class);
    }

  @Test @DisplayName("Ritning av nästlad grupp bevarar geometri och barnstruktur")
  void drawingPreservesGroup()
    {
    Figure child = new Circle(new Point2(10, 20), 5);
    var nested = new CompositeFigure(List.of(child));
    var group = new CompositeFigure(List.of(nested));
    var before = Support.drawing(group);
    Support.assertDrawing(group, before);
    Support.assertDrawing(group, before);
    assertSame(nested, group.parts().get(0));
    assertSame(child, nested.parts().get(0));
    }

  @Test @DisplayName("Nästlad grupp ritar alla löv")
  void nestedDraw()
    {
    Figure a = new Circle(new Point2(10, 20), 5);
    Figure b = new Circle(new Point2(30, 40), 8);
    Figure group = new CompositeFigure(List.of(a, new CompositeFigure(List.of(b))));
    Support.assertDrawing(group, List.of(new Support.Ring(new Point2(10, 20), 5),
        new Support.Ring(new Point2(30, 40), 8)));
    }

  @Test @DisplayName("Nästlad grupp flyttar varje löv en gång")
  void nestedMove()
    {
    Figure a = new Circle(new Point2(10, 20), 5);
    Figure b = new Circle(new Point2(30, 40), 8);
    Figure group = new CompositeFigure(List.of(a, new CompositeFigure(List.of(b))));
    group.move(3, 4);
    Support.assertDrawing(a, List.of(new Support.Ring(new Point2(13, 24), 5)));
    Support.assertDrawing(b, List.of(new Support.Ring(new Point2(33, 44), 8)));
    }

  @Test @DisplayName("Barnlistan skyddas mot ändring")
  void partsProtected()
    {
    var child = new Circle(new Point2(1, 2), 3);
    var source = new java.util.ArrayList<Figure>(List.of(child));
    var group = new CompositeFigure(source);
    source.clear();
    assertEquals(1, group.parts().size());
    assertThrows(UnsupportedOperationException.class, () -> group.parts().clear());
    }

  @Test @DisplayName("Ogiltig gruppflyttning bevarar geometri och nästlad struktur")
  void invalidGroupMovePreservesState()
    {
    Figure a = new Circle(new Point2(10, 20), 5);
    Figure b = new Line(new Point2(30, 40), new Point2(50, 60));
    var nested = new CompositeFigure(List.of(b));
    var group = new CompositeFigure(List.of(a, nested));
    var before = Support.drawing(group);
    for (double invalid : new double[] {
        Double.NaN, Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY })
      {
      assertThrows(IllegalArgumentException.class, () -> group.move(invalid, 2));
      Support.assertDrawing(group, before);
      assertThrows(IllegalArgumentException.class, () -> group.move(2, invalid));
      Support.assertDrawing(group, before);
      }
    assertSame(a, group.parts().get(0));
    assertSame(nested, group.parts().get(1));
    assertSame(b, nested.parts().get(0));
    }

  @Test @DisplayName("Gruppering bevarar identitet, koordinater och avtalad ordning")
  void grouping()
    {
    Figure a = new Circle(new Point2(1, 2), 3);
    Figure b = new Circle(new Point2(5, 6), 4);
    Figure c = new Circle(new Point2(9, 10), 2);
    var document = new model.DrawingDocument(List.of(a, b, c));
    var selection = new model.Selection();
    selection.toggle(a);
    selection.toggle(c);
    model.Groups.group(document, selection);
    assertEquals(2, document.figures().size());
    assertSame(b, document.figures().get(0));
    var group = assertInstanceOf(CompositeFigure.class, document.figures().get(1));
    assertSame(a, group.parts().get(0));
    assertSame(c, group.parts().get(1));
    Support.assertDrawing(a, List.of(new Support.Ring(new Point2(1, 2), 3)));
    }

  @Test @DisplayName("Uppdelning behåller barnens identitet och ordning")
  void ungrouping()
    {
    Figure a = new Circle(new Point2(1, 2), 3);
    Figure b = new Circle(new Point2(5, 6), 4);
    var group = new CompositeFigure(List.of(a, b));
    var document = new model.DrawingDocument(List.of(group));
    var selection = new model.Selection();
    selection.toggle(group);
    model.Groups.ungroup(document, selection);
    assertEquals(2, document.figures().size());
    assertSame(a, document.figures().get(0));
    assertSame(b, document.figures().get(1));
    }

  @Test @DisplayName("Ogiltigt strukturbyte ändrar inte dokumentet")
  void ownership()
    {
    Figure a = new Circle(new Point2(1, 2), 3);
    var group = new CompositeFigure(List.of(a));
    var document = new model.DrawingDocument(List.of(group));
    assertThrows(IllegalArgumentException.class, () -> document.replace(List.of(group, a)));
    assertEquals(1, document.figures().size());
    assertSame(group, document.figures().get(0));
    }

  }
