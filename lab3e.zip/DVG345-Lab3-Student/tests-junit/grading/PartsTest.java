package grading;
import figures.*;
import geometry.Point2;
import rendering.DrawingContext;
import model.DrawingDocument;
import model.Selection;
import model.Groups;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Timeout;
import static org.junit.jupiter.api.Assertions.*;

@Timeout(5)
public class PartsTest
  {
  @Test @DisplayName("Figure.parts är en default-metod; löv returnerar en skyddad tom lista utan ändring")
  void defaultLeaf() throws Exception
    {
    assertTrue(Figure.class.getMethod("parts").isDefault());
    for (Figure leaf : List.of(new Circle(new Point2(10,20),3),
        new Rectangle(new Point2(10,20),8,4),new Square(new Point2(10,20),4),
        new Line(new Point2(10,20),new Point2(30,40))))
      {
      var before=Support.drawing(leaf);
      var parts=leaf.parts();
      assertTrue(parts.isEmpty());
      assertThrows(UnsupportedOperationException.class,parts::clear);
      Support.assertDrawing(leaf,before);
      }
    }

  @Test @DisplayName("CompositeFigure.parts ger skyddade direkta barn, bevarar identitet och ändrar inte gruppen")
  void directParts()
    {
    Figure a=new Circle(new Point2(10,20),3),b=new Circle(new Point2(30,20),4);
    var nested=new CompositeFigure(List.of(b));
    var group=new CompositeFigure(List.of(a,nested));
    var before=Support.drawing(group);
    var parts=group.parts();
    assertEquals(2,parts.size()); assertSame(a,parts.get(0)); assertSame(nested,parts.get(1));
    assertThrows(UnsupportedOperationException.class,parts::clear);
    assertSame(nested,group.parts().get(1)); assertSame(b,nested.parts().get(0));
    Support.assertDrawing(group,before);
    assertTrue(new CompositeFigure(List.of()).parts().isEmpty());
    }

  @Test @DisplayName("Uppdelning behåller markerade löv och nästlade grupper samt deras ordning")
  void mixedSelection()
    {
    Figure outside=new Circle(new Point2(0,0),1),leaf=new Circle(new Point2(10,0),1);
    Figure child=new Circle(new Point2(20,0),1),grandchild=new Circle(new Point2(30,0),1);
    var nested=new CompositeFigure(List.of(grandchild));
    var group=new CompositeFigure(List.of(child,nested));
    var doc=new DrawingDocument(List.of(outside,leaf,group));
    var selection=new Selection(); selection.toggle(group); selection.toggle(leaf);
    Groups.ungroup(doc,selection);
    assertEquals(4,doc.figures().size());
    assertSame(outside,doc.figures().get(0)); assertSame(leaf,doc.figures().get(1));
    assertSame(child,doc.figures().get(2)); assertSame(nested,doc.figures().get(3));
    assertSame(grandchild,nested.parts().get(0));
    assertEquals(3,selection.figures().size());
    assertSame(leaf,selection.figures().get(0)); assertSame(child,selection.figures().get(1));
    assertSame(nested,selection.figures().get(2));
    }

  @Test @DisplayName("Uppdelning behåller en tom sammansättning och dess markering")
  void emptyCompositeStays()
    {
    var empty=new CompositeFigure(List.of());
    var doc=new DrawingDocument(List.of(empty));
    var selection=new Selection();selection.toggle(empty);
    Groups.ungroup(doc,selection);
    assertEquals(1,doc.figures().size());assertSame(empty,doc.figures().get(0));
    assertEquals(1,selection.figures().size());assertSame(empty,selection.figures().get(0));
    assertTrue(empty.parts().isEmpty());
    }

  /** En annan Figure-implementation gör typberoende uppdelning synlig i testerna. */
  private static final class Parts implements Figure
    {
    private final List<Figure> parts;
    Parts(List<Figure> parts) { this.parts=List.copyOf(parts); }
    public List<Figure> parts() { return parts; }
    public Point2 getCenter() { return new Point2(0,0); }
    public void draw(DrawingContext context) { parts.forEach(f -> f.draw(context)); }
    public void move(double dx,double dy) { throw new UnsupportedOperationException(); }
    public void rotate(double radians) { throw new UnsupportedOperationException(); }
    public void rotate(double radians,Point2 pivot) { throw new UnsupportedOperationException(); }
    }

  @Test @DisplayName("Groups.ungroup använder Figure.parts även för andra Figure-implementationer")
  void polymorphicUngroup()
    {
    Figure a=new Circle(new Point2(10,20),3),b=new Circle(new Point2(30,20),4);
    Figure wrapper=new Parts(List.of(a,b));
    var doc=new DrawingDocument(List.of(wrapper));
    var selection=new Selection(); selection.toggle(wrapper);
    Groups.ungroup(doc,selection);
    assertEquals(2,doc.figures().size());
    assertSame(a,doc.figures().get(0)); assertSame(b,doc.figures().get(1));
    }

  @Test @DisplayName("Dokumentvalideringen följer Figure.parts och avvisar delade barn före ändring")
  void polymorphicValidation()
    {
    Figure child=new Circle(new Point2(10,20),3);
    Figure wrapper=new Parts(List.of(child));
    var doc=new DrawingDocument(List.of(wrapper));
    int[] changes={0};doc.addListener(()->changes[0]++);
    assertThrows(IllegalArgumentException.class,()->doc.replace(List.of(wrapper,child)));
    assertSame(wrapper,doc.figures().get(0));assertEquals(0,changes[0]);
    assertThrows(IllegalArgumentException.class,
        ()->new DrawingDocument(List.of(new Parts(List.of(child,child)))));
    }
  }
