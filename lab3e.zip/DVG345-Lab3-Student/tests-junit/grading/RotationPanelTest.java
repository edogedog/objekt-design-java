package grading;
import figures.Line;
import geometry.Point2;
import model.DrawingDocument;
import model.Selection;
import tools.Tool;
import app.DrawingPanel;
import java.util.List;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import javax.swing.SwingUtilities;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class RotationPanelTest
  {
  private Tool tool(DrawingDocument document, Selection selection) throws Exception
    {
    // Samma paneltest körs med labb 3- och labb 4-versionen av verktyget.
    for (var constructor : tools.RotateTool.class.getConstructors())
      {
      if (constructor.getParameterCount() == 2)
        return (Tool)constructor.newInstance(document,selection);
      if (constructor.getParameterCount() == 3)
        return (Tool)constructor.newInstance(document,selection,
            constructor.getParameterTypes()[2].getConstructor().newInstance());
      }
    throw new AssertionError("RotateTool saknar avsedd konstruktor.");
    }

  private void mouse(DrawingPanel panel, int type, int x, int y)
    {
    boolean drag = type == MouseEvent.MOUSE_DRAGGED;
    panel.dispatchEvent(new MouseEvent(panel,type,System.currentTimeMillis(),
        type == MouseEvent.MOUSE_RELEASED ? 0 : InputEvent.BUTTON1_DOWN_MASK,
        x,y,1,false,drag ? MouseEvent.NOBUTTON : MouseEvent.BUTTON1));
    }

  @Test @DisplayName("Swing: musned-drag-musupp når rotationsverktyget och panelen kan rita resultatet")
  void swingMousePath() throws Exception
    {
    var line = new Line(new Point2(10,20),new Point2(30,20));
    var document = new DrawingDocument(List.of(line));
    var selection = new Selection(); selection.toggle(line);
    var rotate = tool(document,selection);
    SwingUtilities.invokeAndWait(()->
      {
      var panel = new DrawingPanel(document,selection); panel.setSize(200,150);
      panel.setTool(rotate);
      mouse(panel,MouseEvent.MOUSE_PRESSED,100,20);
      mouse(panel,MouseEvent.MOUSE_DRAGGED,20,100);
      var image = new BufferedImage(200,150,BufferedImage.TYPE_INT_RGB);
      var graphics = image.createGraphics();
      try { panel.paint(graphics); } finally { graphics.dispose(); }
      mouse(panel,MouseEvent.MOUSE_RELEASED,20,100);
      Support.assertDrawing(line,List.of(new Support.Stroke(new Point2(20,10),new Point2(20,30))));
      var before = Support.drawing(line);
      mouse(panel,MouseEvent.MOUSE_PRESSED,100,20);
      panel.getActionMap().get("cancel").actionPerformed(
          new java.awt.event.ActionEvent(panel,0,"cancel"));
      mouse(panel,MouseEvent.MOUSE_DRAGGED,20,100);
      mouse(panel,MouseEvent.MOUSE_RELEASED,20,100);
      Support.assertDrawing(line,before);
      mouse(panel,MouseEvent.MOUSE_PRESSED,100,20);
      panel.setTool(rotate);
      mouse(panel,MouseEvent.MOUSE_RELEASED,20,100);
      Support.assertDrawing(line,before);
      });
    }
  }
