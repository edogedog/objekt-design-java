package grading;
import figures.*;
import geometry.Point2;
import model.DrawingDocument;
import model.Selection;
import tools.RotateTool;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class RotateToolTest
  {
  @Test @DisplayName("Rotationsverktyg labb 3: nästlad grupp roteras löpande kring fast pivot, musupp dubblerar inte")
  void directNestedRotation()
    {
    var a = new Circle(new Point2(10,20),2);
    var b = new Circle(new Point2(30,20),2);
    var nested = new CompositeFigure(List.of(b));
    var group = new CompositeFigure(List.of(a,nested));
    var doc = new DrawingDocument(List.of(group));
    var selection = new Selection(); selection.toggle(group);
    int[] changed={0}; doc.addListener(()->changed[0]++);
    var tool = new RotateTool(doc,selection);
    tool.pressed(new Point2(100,20),false);
    tool.dragged(new Point2(100,100));
    tool.dragged(new Point2(20,100));
    Support.assertDrawing(a,List.of(new Support.Ring(new Point2(20,10),2)));
    Support.assertDrawing(b,List.of(new Support.Ring(new Point2(20,30),2)));
    tool.released(new Point2(20,100));
    assertEquals(2,changed[0]);
    assertSame(group,doc.figures().get(0)); assertSame(nested,group.parts().get(1));
    tool.dragged(new Point2(-100,20));
    Support.assertDrawing(a,List.of(new Support.Ring(new Point2(20,10),2)));
    }

  @Test @DisplayName("Rotationsverktyg labb 3: flermarkering använder gemensam pivot utan att gruppera dokumentet")
  void multipleSelection()
    {
    var a = new Circle(new Point2(10,20),2);
    var b = new Circle(new Point2(30,20),2);
    var doc = new DrawingDocument(List.of(a,b));
    var selection = new Selection(); selection.toggle(a); selection.toggle(b);
    var tool = new RotateTool(doc,selection);
    tool.pressed(new Point2(100,20),false);
    tool.released(new Point2(20,100));
    Support.assertDrawing(a,List.of(new Support.Ring(new Point2(20,10),2)));
    Support.assertDrawing(b,List.of(new Support.Ring(new Point2(20,30),2)));
    assertSame(a,doc.figures().get(0)); assertSame(b,doc.figures().get(1));
    }

  @Test @DisplayName("Rotationsverktyg labb 3: cancel avslutar gesten och behåller redan utförd rotation")
  void cancelEndsDirectGesture()
    {
    var line = new Line(new Point2(10,20),new Point2(30,20));
    var doc = new DrawingDocument(List.of(line));
    var selection = new Selection(); selection.toggle(line);
    var tool = new RotateTool(doc,selection);
    tool.pressed(new Point2(100,20),false);
    tool.dragged(new Point2(20,100)); tool.cancel();
    tool.released(new Point2(-100,20));
    Support.assertDrawing(line,List.of(new Support.Stroke(new Point2(20,10),new Point2(20,30))));
    }
  }
