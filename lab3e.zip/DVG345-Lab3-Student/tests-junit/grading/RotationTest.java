package grading;
import figures.*;
import geometry.Point2;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Timeout;
import static org.junit.jupiter.api.Assertions.*;

@Timeout(5)
public class RotationTest
  {
  @Test @DisplayName("Rotatable har två abstrakta void-metoder utan defaultimplementation")
  void contract() throws Exception
    {
    assertTrue(Rotatable.class.isAssignableFrom(Figure.class));
    for (var m : List.of(Rotatable.class.getMethod("rotate", double.class),
        Rotatable.class.getMethod("rotate", double.class, Point2.class)))
      {
      assertEquals(void.class, m.getReturnType());
      assertFalse(m.isDefault());
      assertTrue(java.lang.reflect.Modifier.isAbstract(m.getModifiers()));
      }
    }

  @Test @DisplayName("Punktrotation skapar ett nytt värde med angiven pivot")
  void pointRotation()
    {
    var p = new Point2(3, 2);
    var rotated = p.rotated(Math.PI / 2, new Point2(1, 2));
    assertEquals(1, rotated.x(), 1e-8);
    assertEquals(4, rotated.y(), 1e-8);
    assertEquals(new Point2(3, 2), p);
    }

  @Test @DisplayName("Alla grundfigurer roterar kring en extern punkt och bevarar storleken")
  void externalPivot()
    {
    var origin = new Point2(0, 0);
    Figure line = new Line(new Point2(2, 4), new Point2(8, 4));
    line.rotate(Math.PI / 2, origin);
    Support.assertDrawing(line, List.of(new Support.Stroke(new Point2(-4, 2), new Point2(-4, 8))));
    Figure circle = new Circle(new Point2(2, 4), 3);
    circle.rotate(Math.PI / 2, origin);
    Support.assertDrawing(circle, List.of(new Support.Ring(new Point2(-4, 2), 3)));
    Figure rectangle = new Rectangle(new Point2(2, 4), 6, 2);
    rectangle.rotate(Math.PI / 2, origin);
    Support.assertDrawing(rectangle, edges(new Point2(-4, 2), new Point2(-4, 8),
        new Point2(-6, 8), new Point2(-6, 2)));
    Figure square = new Square(new Point2(2, 4), 2);
    square.rotate(Math.PI / 2, origin);
    Support.assertDrawing(square, edges(new Point2(-4, 2), new Point2(-4, 4),
        new Point2(-6, 4), new Point2(-6, 2)));
    }

  private List<Object> edges(Point2 a, Point2 b, Point2 c, Point2 d)
    {
    return List.of(new Support.Stroke(a,b), new Support.Stroke(b,c),
        new Support.Stroke(c,d), new Support.Stroke(d,a));
    }

  @Test @DisplayName("Enparametersrotation använder figurens eget centrum")
  void ownCenter()
    {
    Figure line = new Line(new Point2(2, 4), new Point2(8, 4));
    line.rotate(Math.PI / 2);
    Support.assertDrawing(line, List.of(new Support.Stroke(new Point2(5, 1), new Point2(5, 7))));
    Figure circle = new Circle(new Point2(2, 4), 3);
    circle.rotate(0.7);
    Support.assertDrawing(circle, List.of(new Support.Ring(new Point2(2, 4), 3)));
    for (Figure f : List.of(new Rectangle(new Point2(2, 4), 6, 2), new Square(new Point2(2, 4), 2)))
      {
      var center = f.getCenter();
      f.rotate(Math.PI / 3);
      assertEquals(center.x(), f.getCenter().x(), 1e-8);
      assertEquals(center.y(), f.getCenter().y(), 1e-8);
      }
    }

  @Test @DisplayName("Rektangel och kvadrat kan roteras en vinkel som inte är ett kvartsvarv")
  void obliqueRotation()
    {
    double q = Math.sqrt(2);
    Figure rectangle = new Rectangle(new Point2(0,0), 4, 2);
    rectangle.rotate(Math.PI / 4, new Point2(0,0));
    Support.assertDrawing(rectangle, edges(new Point2(0,0), new Point2(2*q,2*q),
        new Point2(q,3*q), new Point2(-q,q)));
    Figure square = new Square(new Point2(0,0), 2);
    square.rotate(Math.PI / 4, new Point2(0,0));
    Support.assertDrawing(square, edges(new Point2(0,0), new Point2(q,q),
        new Point2(0,2*q), new Point2(-q,q)));
    }

  @Test @DisplayName("Gruppcentrum är medelvärdet av direkta barns centrum; tom grupp har origo")
  void groupCenter()
    {
    var a = new Circle(new Point2(2, 4), 1);
    var b = new Circle(new Point2(10, 8), 10);
    var c = new Circle(new Point2(20, 12), 2);
    var nested = new CompositeFigure(List.of(b,c));
    var group = new CompositeFigure(List.of(a,nested));
    assertEquals(new Point2(15,10), nested.getCenter());
    assertEquals(new Point2(8.5,7), group.getCenter());
    assertEquals(new Point2(0,0), new CompositeFigure(List.of()).getCenter());
    }

  @Test @DisplayName("Nästlad grupp skickar samma pivot till alla löv och bevarar identitet")
  void sharedPivot()
    {
    Figure a = new Circle(new Point2(10,0), 2);
    Figure b = new Line(new Point2(20,0),new Point2(22,0));
    var nested = new CompositeFigure(List.of(b));
    var group = new CompositeFigure(List.of(a,nested));
    group.rotate(Math.PI / 2, new Point2(0,0));
    Support.assertDrawing(a,List.of(new Support.Ring(new Point2(0,10),2)));
    Support.assertDrawing(b,List.of(new Support.Stroke(new Point2(0,20),new Point2(0,22))));
    assertSame(a, group.parts().get(0));
    assertSame(nested, group.parts().get(1));
    assertSame(b, nested.parts().get(0));
    }

  @Test @DisplayName("Gruppens enparametersrotation använder hela gruppens centrum")
  void groupOwnCenter()
    {
    Figure a = new Circle(new Point2(0,0), 1);
    Figure b = new Circle(new Point2(10,0), 1);
    var group = new CompositeFigure(List.of(a,b));
    group.rotate(Math.PI / 2);
    Support.assertDrawing(a,List.of(new Support.Ring(new Point2(5,-5),1)));
    Support.assertDrawing(b,List.of(new Support.Ring(new Point2(5,5),1)));
    }

  @Test @DisplayName("Ogiltiga vinklar och null-pivot avvisas utan ändring, även för tom grupp")
  void invalidRotation()
    {
    for (Figure f : List.of(new Line(new Point2(2,4),new Point2(8,4)),
        new Circle(new Point2(2,4),3), new Rectangle(new Point2(2,4),6,2),
        new Square(new Point2(2,4),2), new CompositeFigure(List.of()),
        new CompositeFigure(List.of(new Circle(new Point2(1,2),3)))))
      {
      var before=Support.drawing(f);
      for(double angle : new double[]{Double.NaN,Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY})
        {
        assertThrows(IllegalArgumentException.class,()->f.rotate(angle));
        assertThrows(IllegalArgumentException.class,()->f.rotate(angle,new Point2(0,0)));
        Support.assertDrawing(f,before);
        }
      assertThrows(NullPointerException.class,()->f.rotate(0,null));
      Support.assertDrawing(f,before);
      f.rotate(0);
      Support.assertDrawing(f,before);
      }
    }

  @Test @DisplayName("Överflöd i ett senare löv lämnar hela gruppen orörd")
  void atomicGroupRotation()
    {
    Figure first=new Circle(new Point2(1,2),3);
    Figure last=new Line(new Point2(Double.MAX_VALUE,Double.MAX_VALUE),new Point2(0,0));
    var group=new CompositeFigure(List.of(first,new CompositeFigure(List.of(last))));
    var before=Support.drawing(group);
    assertThrows(IllegalArgumentException.class,()->group.rotate(Math.PI/4,new Point2(0,0)));
    Support.assertDrawing(group,before);
    }

  @Test @DisplayName("Koordinatöverflöd lämnar även varje grundfigur helt orörd")
  void atomicLeafRotation()
    {
    double big = Double.MAX_VALUE;
    for (Figure f : List.of(new Line(new Point2(1,2),new Point2(big,big)),
        new Circle(new Point2(big,big),1), new Rectangle(new Point2(0,0),big,big),
        new Square(new Point2(0,0),big)))
      {
      var before=Support.drawing(f);
      assertThrows(IllegalArgumentException.class,()->f.rotate(Math.PI/4,new Point2(0,0)));
      Support.assertDrawing(f,before);
      }
    }
  }
