package grading;
import figures.Figure;
import figures.CompositeFigure;
import geometry.Point2;
import rendering.DrawingContext;
import model.Selection;
import model.DrawingDocument;
import model.Groups;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class SelectionTest
  {
  /** Två olika objekt kan vara lika enligt equals. Testet gäller bara markering. */
  private record EqualFigure(int value) implements Figure
    {
    public Point2 getCenter() { return new Point2(value,0); }
    public void draw(DrawingContext context) { context.circle(getCenter(),1); }
    public void move(double dx,double dy) { throw new UnsupportedOperationException(); }
    public void rotate(double radians) { throw new UnsupportedOperationException(); }
    public void rotate(double radians,Point2 pivot) { throw new UnsupportedOperationException(); }
    }

  @Test @DisplayName("Selection.contains jämför identitet och ändrar inte markeringen")
  void identityMembership()
    {
    Figure a=new EqualFigure(1),b=new EqualFigure(1);
    assertEquals(a,b);assertNotSame(a,b);
    var selection=new Selection();
    assertFalse(selection.contains(a));
    selection.toggle(a);
    assertTrue(selection.contains(a));assertFalse(selection.contains(b));
    assertEquals(1,selection.figures().size());assertSame(a,selection.figures().get(0));
    selection.toggle(b);
    assertTrue(selection.contains(a));assertTrue(selection.contains(b));
    selection.toggle(a);
    assertFalse(selection.contains(a));assertTrue(selection.contains(b));
    selection.clear();assertFalse(selection.contains(b));
    }

  @Test @DisplayName("Gruppering skiljer lika figurobjekt åt och behåller dokumentets ritordning")
  void identityGrouping()
    {
    Figure a=new EqualFigure(1),b=new EqualFigure(1),c=new EqualFigure(2);
    var document=new DrawingDocument(List.of(a,b,c));
    var selection=new Selection();selection.toggle(c);selection.toggle(a);
    Groups.group(document,selection);
    assertEquals(2,document.figures().size());assertSame(b,document.figures().get(0));
    var group=assertInstanceOf(CompositeFigure.class,document.figures().get(1));
    assertEquals(2,group.parts().size());
    assertSame(a,group.parts().get(0));assertSame(c,group.parts().get(1));
    assertTrue(selection.contains(group));assertFalse(selection.contains(a));
    }
  }
