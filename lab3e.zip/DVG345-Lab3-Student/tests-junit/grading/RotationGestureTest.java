package grading;
import figures.*;
import geometry.Point2;
import model.DrawingDocument;
import model.Selection;
import tools.RotationGesture;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

public class RotationGestureTest
  {
  @Test @DisplayName("Rotationsgest: flermarkering behålls, pivot fångas och modellen ändras inte")
  void selectionAndPivot()
    {
    var a = new Circle(new Point2(10,20),2);
    var b = new Circle(new Point2(30,20),2);
    var doc = new DrawingDocument(List.of(a,b));
    var selection = new Selection(); selection.toggle(b); selection.toggle(a);
    var gesture = new RotationGesture(doc,selection);
    gesture.begin(new Point2(10,20),false);
    assertTrue(gesture.active());
    assertEquals(new Point2(20,20),gesture.pivot());
    assertEquals(2,selection.figures().size());
    gesture.advance(new Point2(20,10));
    assertEquals(Math.PI/2,gesture.radians(),1e-10);
    assertEquals(new Point2(10,20),a.getCenter());
    assertEquals(new Point2(30,20),b.getCenter());
    }

  @Test @DisplayName("Rotationsgest: passage över atan2-gränsen ger en liten vinkel och flera varv kan ackumuleras")
  void angleBoundary()
    {
    var line = new Line(new Point2(-10,0),new Point2(10,0));
    var doc = new DrawingDocument(List.of(line));
    var selection = new Selection(); selection.toggle(line);
    var gesture = new RotationGesture(doc,selection);
    gesture.begin(new Point2(-100,1),false);
    double delta = gesture.advance(new Point2(-100,-1));
    assertEquals(2*Math.atan(0.01),delta,1e-10);
    gesture.begin(new Point2(100,0),false);
    for (int i=0;i<2;i++)
      {
      gesture.advance(new Point2(0,100)); gesture.advance(new Point2(-100,0));
      gesture.advance(new Point2(0,-100)); gesture.advance(new Point2(100,0));
      }
    assertEquals(4*Math.PI,gesture.radians(),1e-10);
    }

  @Test @DisplayName("Rotationsgest: tom markering, Shift-klick och pivot startar ingen rotation; cancel nollställer")
  void idleAndSelection()
    {
    var circle = new Circle(new Point2(20,20),5);
    var doc = new DrawingDocument(List.of(circle));
    var selection = new Selection();
    var gesture = new RotationGesture(doc,selection);
    gesture.begin(new Point2(100,20),false);
    assertFalse(gesture.active());
    gesture.begin(new Point2(22,20),true);
    assertFalse(gesture.active()); assertSame(circle,selection.figures().get(0));
    gesture.begin(new Point2(20,20),false);
    assertFalse(gesture.active());
    gesture.begin(new Point2(100,20),false);
    assertTrue(gesture.active());
    assertEquals(0,gesture.advance(new Point2(20,20)));
    assertEquals(Math.PI/2,gesture.advance(new Point2(20,100)),1e-10);
    gesture.cancel();
    assertFalse(gesture.active()); assertEquals(0,gesture.advance(new Point2(100,20)));
    }
  }
