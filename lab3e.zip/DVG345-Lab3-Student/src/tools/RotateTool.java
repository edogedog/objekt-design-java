package tools;
import geometry.Point2;
import model.DrawingDocument;
import model.Selection;
import rendering.DrawingContext;

/** Labb 3: direkt rotation under dragning. Escape avslutar utan återställning.
 * RotationGesture äger gestens tillstånd och fasta pivot; figurerna äger geometrin.
 */
public final class RotateTool implements Tool
  {
  private final DrawingDocument document;
  private final RotationGesture gesture;

  public RotateTool(DrawingDocument document, Selection selection)
    {
    this.document = document;
    gesture = new RotationGesture(document, selection);
    }

  @Override
  public void pressed(Point2 point, boolean extend)
    {
    gesture.begin(point, extend);
    }

  @Override
  public void dragged(Point2 point)
    {
    if (!gesture.active()) return;
    double delta = gesture.advance(point);
    if (delta == 0) return;
    try
      {
      gesture.target().rotate(delta, gesture.pivot());
      document.changed();
      }
    catch (RuntimeException ex)
      {
      cancel();
      throw ex;
      }
    }

  @Override
  public void released(Point2 point)
    {
    try { dragged(point); }
    finally { cancel(); }
    }

  @Override
  public void cancel() { gesture.cancel(); }

  @Override
  public void drawPreview(DrawingContext context) { gesture.drawGuide(context); }
  }
