
package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import figures.CompositeFigure;
import figures.Figure;

public final class Groups {

    private Groups() {
    }

    public static void group(
            DrawingDocument document,
            Selection selection) {

        Objects.requireNonNull(document, "document");
        Objects.requireNonNull(selection, "selection");

        List<Figure> original = document.figures();
        List<Figure> selected = new ArrayList<>();

        int topIndex = -1;

        // Hämta markerade figurer i ritordning
        for (int i = 0; i < original.size(); i++) {
            Figure figure = original.get(i);

            if (selection.contains(figure)) {
                selected.add(figure);
                topIndex = i;
            }
        }

        // Minst två figurer krävs
        if (selected.size() < 2) {
            return;
        }

        CompositeFigure composite =
                new CompositeFigure(selected);

        List<Figure> next = new ArrayList<>();

        //sätt grupp på översta markerad
        for (int i = 0; i < original.size(); i++) {
            Figure figure = original.get(i);

            if (i == topIndex) {
                next.add(composite);
            }

            if (!selection.contains(figure)) {
                next.add(figure);
            }
        }

        document.replace(next);

        selection.clear();
        selection.toggle(composite);
    }

    public static void ungroup(
            DrawingDocument document,
            Selection selection) {

        Objects.requireNonNull(document, "document");
        Objects.requireNonNull(selection, "selection");

        List<Figure> next = new ArrayList<>();
        List<Figure> newSelection = new ArrayList<>();

        boolean changed = false;

        for (Figure figure : document.figures()) {

            if (selection.contains(figure)
                    && !figure.parts().isEmpty()) {

                // bara the child
                List<Figure> children = figure.parts();

                next.addAll(children);
                newSelection.addAll(children);

                changed = true;

            } else {

                // vanlgia bli kbar
                next.add(figure);

                if (selection.contains(figure)) {
                    newSelection.add(figure);
                }
            }
        }

        if (!changed) {
            return;
        }

        document.replace(next);

        selection.clear();

        for (Figure figure : newSelection) {
            selection.toggle(figure);
        }
    }

    // stöd
    public static void group(
            Selection selection,
            DrawingDocument document) {

        group(document, selection);
    }

    public static void ungroup(
            Selection selection,
            DrawingDocument document) {

        ungroup(document, selection);
    }
}
