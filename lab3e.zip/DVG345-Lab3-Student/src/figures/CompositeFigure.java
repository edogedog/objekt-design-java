
package figures;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Objects;

import geometry.Point2;
import geometry.TransformChecks;
import rendering.DrawingContext;

public final class CompositeFigure implements Figure {

    private final List<Figure> children;

    public CompositeFigure(List<Figure> children) {
        Objects.requireNonNull(children, "children");

        this.children = List.copyOf(children);

        // samma figurobjekt får inte händaaaaaaa två gånger
        IdentityHashMap<Figure, Boolean> seen =
                new IdentityHashMap<>();

        for (Figure figure : this.children) {
            checkUnique(figure, seen);
        }
    }

    private static void checkUnique(
            Figure figure,
            IdentityHashMap<Figure, Boolean> seen) {

        Objects.requireNonNull(figure, "figure");

        if (seen.put(figure, Boolean.TRUE) != null) {
            throw new IllegalArgumentException(
                    "Duplicate figure");
        }

        for (Figure child : figure.parts()) {
            checkUnique(child, seen);
        }
    }

    @Override
    public List<Figure> parts() {
        return children;
    }

    @Override
    public void draw(DrawingContext context) {
        Objects.requireNonNull(context, "context");

        for (Figure figure : children) {
            figure.draw(context);
        }
    }

    @Override
    public Point2 getCenter() {
        if (children.isEmpty()) {
            return new Point2(0, 0);
        }

        double x = 0;
        double y = 0;
        int count = children.size();

        for (Figure figure : children) {
            Point2 center = figure.getCenter();

            x += center.x() / count;
            y += center.y() / count;
        }

        return new Point2(x, y);
    }

    @Override
    public void move(double dx, double dy) {

        //kiontroll
        TransformChecks.translation(this, dx, dy);

        for (Figure figure : children) {
            figure.move(dx, dy);
        }
    }

    @Override
    public void rotate(double radians) {
        rotate(radians, getCenter());
    }

    @Override
    public void rotate(double radians, Point2 pivot) {

        Objects.requireNonNull(pivot, "pivot");

       //kontroll
        TransformChecks.rotation(this, radians, pivot);

        for (Figure figure : children) {
            figure.rotate(radians, pivot);
        }
    }
}
