
package figures;

import java.util.Objects;

import geometry.Point2;
import rendering.DrawingContext;

/** STUDENTUPPGIFT: Kvadrat med positiv, ändlig sidlängd. */
public final class Square implements Figure {

    // fuskigt knepp här som jag kanske kommer ångra i framtiden, återanvämdnder rektangel
    private final Rectangle rectangle;

    public Square(Point2 topLeft, double side) {

        Objects.requireNonNull(topLeft, "Square topLeft");

        // tittar p åsidlängden
        if (!Double.isFinite(side) || side <= 0) {
            throw new IllegalArgumentException("Invalid side");
        }

      //asssåt yp samma som rektange l gör likannde check också
        this.rectangle = new Rectangle(topLeft, side, side);
    }

    @Override
    public void draw(DrawingContext context) {
        rectangle.draw(context);
    }

    @Override
    public Point2 getCenter() {
        return rectangle.getCenter();
    }

    @Override
    public void move(double dx, double dy) {
        rectangle.move(dx, dy);
    }

    @Override
    public void rotate(double radians) {
        rectangle.rotate(radians);
    }

    @Override
    public void rotate(double radians, Point2 pivot) {
        rectangle.rotate(radians, pivot);
    }
}
