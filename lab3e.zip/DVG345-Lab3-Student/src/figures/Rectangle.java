package figures;

import java.util.List;

import java.util.Objects;

import geometry.Point2;
import rendering.DrawingContext;

/**
 * STUDENTUPPGIFT: axelparallell rektangel, beskriven av övre vänstra hörnet,
 * bredd och höjd. Båda måtten ska vara positiva och ändliga.
 */

public final class Rectangle implements Figure {

//4 punkter dennna gång 
	private Point2 topLeft, topRight, bottomLeft, bottomRight;


	/** Skapar rektangeln. Även de beräknade hörnen måste vara ändliga. */
	public Rectangle(Point2 topLeft, double width, double height) {

		this.topLeft = Objects.requireNonNull(topLeft, "rectangle width");

		// checkar om bra width
		if (width <= 0) {
			throw new IllegalArgumentException("större än noll!");
		}
		// checkar om finite
		if (!Double.isFinite(topLeft.x() + width)) {
			throw new IllegalArgumentException("måste vara vanligt double");
		}
		// checkar om finite
		if (!Double.isFinite(width)) {
			throw new IllegalArgumentException("måste vara vanligt double");
		}

		// checkar om bra höjd
		if (height <= 0) {
			throw new IllegalArgumentException("större än noll!");
		}
		// checkar om finite
		if (!Double.isFinite(topLeft.y() + height)) {
			throw new IllegalArgumentException("måste vara vanligt double");
		}
		// checkar om finite
		if (!Double.isFinite(height)) {
			throw new IllegalArgumentException("måste vara vanligt double");
		}
		this.topRight = new Point2(topLeft.x() + width, topLeft.y());
		this.bottomLeft = new Point2(topLeft.x(), topLeft.y() + height);
		this.bottomRight = new Point2(topLeft.x() + width, topLeft.y() + height);

	}

	// gör om det här och gör det mycke snyggare än de va förr, förr hade jag
	// uträkningar här
	// nu bara en line me alla som ritar alla istället för 3 uträkningar, och 3
	// linjer me draw bara en enda
	@Override
	public void draw(DrawingContext context) {
		context.polygon(List.of(topLeft, topRight, bottomRight, bottomLeft));
	}

	@Override
	public Point2 getCenter() {
		return new Point2(topLeft.x() / 2 + bottomRight.x() / 2, topLeft.y() / 2 + bottomRight.y() / 2);
	}

	@Override
	public void move(double dx, double dy) {
		Point2 newTL = topLeft.translated(dx, dy);
		Point2 newTR = topRight.translated(dx, dy);
		Point2 newBL = bottomLeft.translated(dx, dy);
		Point2 newBR = bottomRight.translated(dx, dy);

		// Validate all corners before changing anything
		for (Point2 p : List.of(newTL, newTR, newBL, newBR)) {
			if (!Double.isFinite(p.x()) || !Double.isFinite(p.y())) {
				throw new IllegalArgumentException();
			}
		}

		topLeft = newTL;
		topRight = newTR;
		bottomLeft = newBL;
		bottomRight = newBR;
	}

	@Override
	public void rotate(double radians) {
		rotate(radians, getCenter());
	}

	@Override
	public void rotate(double radians, Point2 pivot) {
		Objects.requireNonNull(pivot, "pivot");

		if (!Double.isFinite(radians)) {
			throw new IllegalArgumentException("Invalid angle");
		}

		Point2 newTL = topLeft.rotated(radians, pivot);
		Point2 newTR = topRight.rotated(radians, pivot);
		Point2 newBL = bottomLeft.rotated(radians, pivot);
		Point2 newBR = bottomRight.rotated(radians, pivot);

		for (Point2 p : List.of(newTL, newTR, newBL, newBR)) {
			if (!Double.isFinite(p.x()) || !Double.isFinite(p.y())) {
				throw new IllegalArgumentException("Invalid coordinates");
			}
		}

		topLeft = newTL;
		topRight = newTR;
		bottomLeft = newBL;
		bottomRight = newBR;
	}

}
