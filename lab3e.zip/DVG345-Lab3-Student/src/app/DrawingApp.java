package app;
import model.DrawingDocument;
import model.Selection;
import tools.CircleTool;
import tools.MoveTool;
import tools.RotateTool;
import java.awt.BorderLayout;
import javax.swing.*;
import model.Groups;

/** Kopplingspunkt för dokument, verktyg och vy. */
public final class DrawingApp
  {
  public static void main(String[] args)
    {
    SwingUtilities.invokeLater(() ->
      {
      var document = new DrawingDocument(DemoContent.create());
      var selection = new Selection();
      var panel = new DrawingPanel(document, selection);
      
      var toolbar = new JPanel();
      var status = new JLabel("Verktyg: Flytta");
      JButton move = new JButton("Flytta / markera");
      JButton circle = new JButton("Cirkel");
      move.addActionListener(event ->
        {
        panel.setTool(new MoveTool(document, selection));
        status.setText("Verktyg: Flytta");
        });
      circle.addActionListener(event ->
        {
        panel.setTool(new CircleTool(document));
        status.setText("Verktyg: Cirkel");
        });
      toolbar.add(move);
      toolbar.add(circle);
      JButton group = new JButton("Gruppera");
      JButton split = new JButton("Dela upp");
      group.addActionListener(event ->
        {
        panel.cancelGesture();
        Groups.group(document, selection);
        panel.repaint();
        });
      split.addActionListener(event ->
        {
        panel.cancelGesture();
        Groups.ungroup(document, selection);
        panel.repaint();
        });
      toolbar.add(group);
      toolbar.add(split);
      JButton rotate = new JButton("Rotera");
      rotate.setToolTipText("Markera en figur eller grupp och dra runt dess centrum. Shift-klick bygger markering.");
      rotate.addActionListener(event ->
        {
        panel.setTool(new RotateTool(document, selection));
        status.setText("Rotera: dra runt markerade figurers centrum; Shift-klick markerar flera. Esc avslutar.");
        });
      toolbar.add(rotate);
      panel.setTool(new MoveTool(document, selection));
      JFrame frame = new JFrame("DVG345 – labb 3");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.add(toolbar, BorderLayout.NORTH);
      frame.add(panel, BorderLayout.CENTER);
      frame.add(status, BorderLayout.SOUTH);
      frame.pack();
      frame.setLocationByPlatform(true);
      frame.setVisible(true);
      });
    }
  }
