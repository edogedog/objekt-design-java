
package app;

import java.util.List;

import figures.Circle;
import figures.CompositeFigure;
import figures.Figure;
import figures.Line;
import figures.Rectangle;
import figures.Square;

import geometry.Point2;

public final class DemoContent {

    private DemoContent() {
    }

    public static List<Figure> create() {

        // husets väggar så att söäga
        Rectangle walls = new Rectangle(
                new Point2(90, 130),
                140,
                120
        );

        // dörr
        Rectangle door = new Rectangle(
                new Point2(145, 190),
                30,
                60
        );

        // fönster
        Square window = new Square(
                new Point2(110, 155),
                25
        );

        //group 1
        CompositeFigure houseBody =
                new CompositeFigure(
                        List.of(walls, door, window)
                );

        // takett grej
        Line roofLeft = new Line(
                new Point2(90, 130),
                new Point2(160, 60)
        );

        Line roofRight = new Line(
                new Point2(160, 60),
                new Point2(230, 130)
        );

        //andra grupp förta
        CompositeFigure entireHouse =
                new CompositeFigure(
                        List.of(
                                houseBody,
                                roofLeft,
                                roofRight
                        )
                );

        // en fin solll
        Circle sun = new Circle(
                new Point2(300, 75),
                30
        );

        // taeckningen
        return List.of(entireHouse, sun);
    }
}
